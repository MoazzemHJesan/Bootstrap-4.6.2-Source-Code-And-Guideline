---
title: Blockquote right
categories:
  - Typography
tags:
  - text
  - type
---
