---
title: Calendar2 minus fill
categories:
  - Date and time
tags:
  - date
  - time
  - month
---
